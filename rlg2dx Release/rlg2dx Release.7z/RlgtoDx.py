# -*- coding: utf-8 -*-	
import b_Rlg2Dx_translate
if __name__ == '__main__':
	b_Rlg2Dx_translate.run()